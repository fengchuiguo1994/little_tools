use strict;
use warnings;

my $in = $ARGV[0];
open IN,"<$in";

my $all;
my $combine;
my $uncombine;
my $combine_rate;
my @tmp;
while(<IN>)
{
	if($_=~/FLASH\s+Total.+?(\d+)/)
	{
		$all = $1;
	}
	if($_=~/FLASH\s+Combined.+?(\d+)/)
	{
		$combine = $1;
	}
	if($_=~/FLASH\s+Uncombined.+?(\d+)/)
	{
		$uncombine = $1;
	}
	if($_=~/FLASH\s+Percent.+?(\d+\.\d+%)/)
	{
		$combine_rate = $1;
	}
}