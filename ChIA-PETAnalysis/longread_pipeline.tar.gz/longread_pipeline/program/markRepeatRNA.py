import sys
import copy

### Operating common files  ###
import gzip
def readFile(infile):
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

### Operating sam/bam files  ###
import pysam
def readSam(insamfile):
    if insamfile.endswith(".bam"):
        insam = pysam.AlignmentFile(insamfile,'rb')
    elif insamfile.endswith(".sam.gz"):
        insam = pysam.AlignmentFile(insamfile,'rb')
    elif insamfile.endswith(".sam"):
        insam = pysam.AlignmentFile(insamfile,'r')
    else:
        raise ValueError("the input sam/bam file is not end with sam or bam!")
    return insam
        
def writeSam(outsamfile,header):
    if outsamfile.endswith(".bam"):
        outsam = pysam.AlignmentFile(outsamfile,'wb',header=header)
    elif outsamfile.endswith(".sam"):
        outsam = pysam.AlignmentFile(outsamfile,'w',header=header)
    else:
        raise ValueError("the output sam/bam file is not end with sam or bam!")
    return outsam

### Interval tree ###
from bx.intervals.intersection import Intersecter, Interval
def regionTree(chrom,start,end,info,resFrag):
    if chrom not in resFrag:
        resFrag[chrom] = Intersecter()
    resFrag[chrom].add_interval(Interval(int(start),int(end),info))

def regionFind(tree,start,end):
    return tree.find(start,end)

class SamRead:
    def __init__(self,infile):
        self.fin = readSam(infile)
    def __iter__(self):
        flag = None
        outlist = []
        for read in self.fin:
            if flag != None and flag != read.query_name:
                yield outlist
                outlist = []
            outlist.append(read)
            flag = read.query_name
        self.fin.close()
        yield outlist
    def header(self):
        return self.fin.header

def overlap(mylist,genetree,repeattreeCon,librarytype,fall):
    mydict = {}
    NN = len(mylist) # may be less than get_tag("NH")
    for ii in mylist:
        # print(ii)
        chrom = ii.reference_name
        strand = "+"
        if ii.is_reverse:
            strand = "-"
        tmpoverlap = set()
        if chrom in genetree:
            for start,end in ii.blocks:
                # tmpoverlap.update(regionFind(genetree[chrom],start,end))
                tmpoverlap.update(["##".join(x.value) for x in regionFind(genetree[chrom],start,end)])
        # if len(tmpoverlap) == 0:
        if len(tmpoverlap) == 0:
            if chrom in repeattreeCon:
                for start,end in ii.blocks:
                    # tmpoverlap.update(regionFind(repeattreeCon[chrom],start,end))
                    tmpoverlap.update(["##".join(x.value) for x in regionFind(repeattreeCon[chrom],start,end)])
        # print(tmpoverlap)
        tmpread = copy.deepcopy(ii)
        if len(tmpoverlap) == 0:
            tmpread.set_tag("ZM","nofeature")
        else:
            tmpread.set_tag("ZM","{0}".format(",".join(tmpoverlap)))
        fall.write(tmpread)
        for jj in tmpoverlap:
            flag = None
            gene,std = jj.split("##") # gene/repeat  strand
            if librarytype == "F":
                if std == strand:
                    flag = "sense"
                else:
                    flag = "anti-sense"
            else:
                if std == strand:
                    flag = "anti-sense"
                else:
                    flag = "sense"
            tmpstr = "{0}##{1}".format(gene,flag)
            if tmpstr not in mydict:
                mydict[tmpstr] = 0
            mydict[tmpstr] += 1
    if len(mydict) == 0:
        return "nofeature","nofeature"
    result = sorted(mydict.items(),key=lambda x:(x[1]),reverse=True)
    if len(result) == 1:
        return result[0][0],"{0}:{1}".format(result[0][0],result[0][1])
    else:
        tmpstr = "{0}:{1}".format(result[0][0],result[0][1])
        for k,v in result[1:]:
            tmpstr += ";{0}:{1}".format(k,v)
        if result[0][1] >= result[1][1]*10:
            return result[0][0],tmpstr
        elif result[0][1] >= result[1][1]*5 and result[0][1] >= NN*0.6:
            return result[0][0]+"##part",tmpstr
        else:
            if len(result) == 2:
                tmp1 = result[0][0].split("##")
                tmp2 = result[1][0].split("##")
                if tmp1[0] == tmp2[0]:
                    return tmp1[0]+"##sense##ambiguous",tmpstr
                else:
                    return "ambiguous",tmpstr
            else:
                return "ambiguous",tmpstr

repeattreeRM = set()
fin = readFile(sys.argv[1])
tmpdict = {}
for line in fin:
    tmp = line.strip().split()
    tmpdict[tmp[0]] = tmp[1].split(".")[0]
fin.close()

fin = readFile(sys.argv[2])
genetree = {}
for line in fin:
    tmp = line.strip().split()
    if tmp[3] not in tmpdict:
        sys.exit("there are not match: \n{0}".format(line))
    regionTree(tmp[0],tmp[1],tmp[2],[tmpdict[tmp[3]],tmp[5]],genetree)
    repeattreeRM.add(tmpdict[tmp[3]])
fin.close()

fin = readFile(sys.argv[3])
repeattreeCon = {}
snRNAdict = {"U1":"U1","U2":"U2","U3":"U3","U4":"U4","U5":"U5","U6":"U6","U7":"U7","U8":"SNORD118","U13":"SNORD13","U13_":"SNORD13","U14":"SNORD14","U17":"SNORA73"}
for line in fin:
    tmp = line.strip().split()
    tmp[3] = tmp[3].replace("?","")
    tmp[6] = tmp[6].replace("?","")
    tmp[7] = tmp[7].replace("?","")
    if tmp[6] == "Simple_repeat" or tmp[6] == "Low_complexity":
        continue
    if tmp[6] == "Satellite": # 卫星DNA由串联排列、不断重复的非编码DNA组成，它是着丝粒的主要组成部分，也是异染色质的主要结构部分.卫星DNA经常出现在转录单位里。(https://zh.wikipedia.org/wiki/%E8%A1%9B%E6%98%9FDNA)(https://en.wikipedia.org/wiki/Satellite_DNA)
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
    elif tmp[3] == "5S" or tmp[3] == "7SK":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[3],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[3])
    elif tmp[3] == "7SLRNA":
        regionTree(tmp[0],tmp[1],tmp[2],["7SL",tmp[5]],repeattreeCon)
        repeattreeRM.add("7SL")
    elif tmp[3] == "LSU-rRNA_Hsa" or tmp[3] == "SSU-rRNA_Hsa":
        regionTree(tmp[0],tmp[1],tmp[2],["45S",tmp[5]],repeattreeCon)
        repeattreeRM.add("45S")
    elif tmp[6] == "SINE":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[7])
    elif tmp[6] == "DNA" and tmp[7] == "DNA":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[3],tmp[5]],repeattreeCon)
    elif tmp[6] == "DNA":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
    elif tmp[6] == "LINE":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[7])
    elif tmp[6] == "LTR" and tmp[7] == "LTR":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[3],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[3])
    elif tmp[6] == "LTR":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[7])
    elif tmp[6] == "RC":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
    elif tmp[6] == "Retroposon":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[7],tmp[5]],repeattreeCon)
    elif tmp[6] == "scRNA":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[3],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[3])
    elif tmp[6] == "snRNA":
        regionTree(tmp[0],tmp[1],tmp[2],[snRNAdict[tmp[3]],tmp[5]],repeattreeCon)
        repeattreeRM.add(snRNAdict[tmp[3]])
    elif tmp[6] == "tRNA":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[6],tmp[5]],repeattreeCon)
        repeattreeRM.add(tmp[6])
    elif tmp[6] == "Unknown":
        regionTree(tmp[0],tmp[1],tmp[2],[tmp[3],tmp[5]],repeattreeCon)
    else:
        sys.exit("some are omissions\n{0}".format(line))
fin.close()

libraty = sys.argv[4]
fin = SamRead(sys.argv[5])
fout = writeFile(sys.argv[6])
fsam = writeSam(sys.argv[7],header=fin.header())
fall = writeSam(sys.argv[8],header=fin.header())
markdict = {}
for reads in fin:
    if len(reads) == 1:
        if reads[0].is_unmapped:
            if "unmapped" not in markdict:
                markdict["unmapped"] = 0
            markdict["unmapped"] += 1
            reads[0].set_tag("ZM","unmapped")
            fall.write(reads[0])
        else:
            outflag = ""
            mark,markpro = overlap(reads,genetree,repeattreeCon,libraty,fall)
            if mark == "nofeature":
                if "uniq-nofeature" not in markdict:
                    markdict["uniq-nofeature"] = 0
                markdict["uniq-nofeature"] += 1
                outflag = "uniq-nofeature"
                fsam.write(reads[0])
            elif mark == "ambiguous":
                if "uniq-ambiguous" not in markdict:
                    markdict["uniq-ambiguous"] = 0
                markdict["uniq-ambiguous"] += 1
                tmpflag = False
                for iii in markpro.split(";"):
                    if iii.split("##")[0] not in repeattreeRM:
                        tmpflag = True
                        break
                if tmpflag:
                    fsam.write(reads[0])
                    if "uniq-ambiguous-out" not in markdict:
                        markdict["uniq-ambiguous-out"] = 0
                    markdict["uniq-ambiguous-out"] += 1
                    outflag = "uniq-ambiguous-out"
                else:
                    if "uniq-ambiguous-drop" not in markdict:
                        markdict["uniq-ambiguous-drop"] = 0
                    markdict["uniq-ambiguous-drop"] += 1
                    outflag = "uniq-ambiguous-drop"
            else:
                tmps = mark.split("##")
                if tmps[0] not in repeattreeRM:
                    if "uniq-feature-out" not in markdict:
                        markdict["uniq-feature-out"] = 0
                    markdict["uniq-feature-out"] += 1
                    outflag = "uniq-feature-out"
                    fsam.write(reads[0])
                else:
                    if "uniq-feature-drop" not in markdict:
                        markdict["uniq-feature-drop"] = 0
                    markdict["uniq-feature-drop"] += 1
                    outflag = "uniq-feature-drop"
                if "uniq-feature" not in markdict:
                    markdict["uniq-feature"] = 0
                markdict["uniq-feature"] += 1
            strand = "+"
            if reads[0].is_reverse:
                strand = "-"
            fout.write("{0}\t{1}\t{2}\t{3}\t.\t{4}\tuniq\t{5}\t{6}\t{7}\n".format(
                reads[0].reference_name,reads[0].reference_start,reads[0].reference_end,reads[0].qname,strand,mark,markpro,outflag))
    else:
        mark,markpro = overlap(reads,genetree,repeattreeCon,libraty,fall)
        outflag = ""
        if "ambiguous" == mark:
            if "multi-ambiguous" not in markdict:
                markdict["multi-ambiguous"] = 0
            markdict["multi-ambiguous"] += 1
            outflag = "multi-ambiguous"
        elif "nofeature" == mark:
            if "multi-nofeature" not in markdict:
                markdict["multi-nofeature"] = 0
            markdict["multi-nofeature"] += 1
            outflag = "multi-nofeature"
        else:
            if "multi-feature" not in markdict:
                markdict["multi-feature"] = 0
            markdict["multi-feature"] += 1
            outflag = "multi-feature"
        fout.write("-\t-\t-\t{0}\t.\t+\tmulti\t{1}\t{2}\t{3}\n".format(
            reads[0].qname,mark,markpro,outflag))
fout.close()
fsam.close()
fall.close()
for k in markdict:
    print("{0}: {1}".format(k,markdict[k]))