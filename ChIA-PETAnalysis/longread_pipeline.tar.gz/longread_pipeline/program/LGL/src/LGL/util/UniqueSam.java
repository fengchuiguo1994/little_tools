/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LGL.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;

/**
 *
 * @author changhd
 */
public class UniqueSam {

    public UniqueSam(String Inputfile, String OutputFile) throws IOException {
        BufferedReader FileIn = new BufferedReader(new InputStreamReader(new FileInputStream(Inputfile)));
        PrintWriter fileOut = new PrintWriter(new FileOutputStream(new File(OutputFile)));
        String line;
        String header = "";
        String sequence = "";
        String[] lastlines = new String[5];
        Arrays.fill(lastlines, null);
        int AS = 0;
        int XS = 0;
        while ((line = FileIn.readLine()) != null) {
            if (!line.startsWith("@")) {
                if (lastlines[0] == null) {
                    String[] fields = line.split("\t");
                    lastlines[0] = fields[0];
                    lastlines[1] = fields[4];
                    lastlines[4] = line;
                    for (int i = 0; i < fields.length; i++) {
                        if (fields[i].startsWith("AS:i")) {
                            String[] ASs = fields[i].split(":");
                            lastlines[2] = ASs[2];
                        }
                        if (fields[i].startsWith("XS:i")) {
                            String[] XSs = fields[i].split(":");
                            lastlines[3] = XSs[2];
                        }
                    }
                } else {
                    String[] fields = line.split("\t");
                    if (lastlines[0].equalsIgnoreCase(fields[0])) {
                        for (int i = 0; i < fields.length; i++) {
                            if (fields[i].startsWith("AS:i")) {
                                String[] ASs = fields[i].split(":");
                                AS = Integer.parseInt(ASs[2]);
                            }
                            if (fields[i].startsWith("XS:i")) {
                                String[] XSs = fields[i].split(":");
                                XS = Integer.parseInt(XSs[2]);
                            }
                        }
//                        System.out.println(lastlines[4]);
                        if (AS - XS > Integer.parseInt(lastlines[2]) - Integer.parseInt(lastlines[3])) {
                            lastlines[2] = String.valueOf(AS);
                            lastlines[3] = String.valueOf(XS);
                            lastlines[0] = fields[0];
                            lastlines[1] = fields[4];
                            lastlines[4] = line;
                        } else if ((AS - XS == Integer.parseInt(lastlines[2]) - Integer.parseInt(lastlines[3])) && (Integer.parseInt(fields[4]) > Integer.parseInt(lastlines[1]))) {
                            lastlines[2] = String.valueOf(AS);
                            lastlines[3] = String.valueOf(XS);
                            lastlines[0] = fields[0];
                            lastlines[1] = fields[4];
                            lastlines[4] = line;
                        }
                    } else {
//                        sequence += lastlines[4];
                        fileOut.println(lastlines[4]);
                        Arrays.fill(lastlines, null);
//                        System.out.println(fields[0]);
                        lastlines[0] = fields[0];
                        lastlines[1] = fields[4];
                        lastlines[4] = line;
                        for (int i = 0; i < fields.length; i++) {
                            if (fields[i].startsWith("AS:i")) {
                                String[] ASs = fields[i].split(":");
                                lastlines[2] = ASs[2];
                            }
                            if (fields[i].startsWith("XS:i")) {
                                String[] XSs = fields[i].split(":");
                                lastlines[3] = XSs[2];
                            }
                        }
                    }
                }
            } else {
//                header += line + "\n";
                fileOut.println(line);
            }

        }
//        sequence += lastlines[4];
//        fileOut.println(header.substring(0, header.length() - 1) + "\n" + sequence);
        fileOut.println(lastlines[4]);
        FileIn.close();
        fileOut.close();
    }

    public static void main(String[] args) throws IOException {
        if (args.length == 2) {
            new UniqueSam(args[0], args[1]);
        } else {
            System.out.println("Usage: java UniqueSam <inputFile> <OutputFile>");
        }
    }

}
