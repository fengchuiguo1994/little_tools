import collections
import sys

def main(filein,filegtf,outfile):
    # mark the gene local 
    hashgtf = {}
    with open(filegtf) as gtf:
        for line in gtf:
            tmp = line.strip().split()
            hashgtf[tmp[6]] = "\t".join([tmp[0],tmp[1],tmp[2]])

    # load the bedpe file, and store it
    gene_region = {}
    gene_count = collections.OrderedDict()
    with open(filein) as fin:
        for line in fin:
            tmp = line.strip().split()
            if not tmp[13].startswith("__"):
                for geneid in tmp[13].split(';'):
                    gene = geneid.split('-')[0]
                    if gene not in gene_region:
                        gene_region[gene] = []
                        gene_count[gene] = 0
                    gene_count[gene] += 1
                    gene_region[gene].append([tmp[0],int(tmp[1]),int(tmp[2])])
    
    # merge DNA region and count
    with open(outfile,'w') as fout:
        for gene in gene_count.keys():
            DNAregion = sorted(gene_region[gene],key=lambda x:(x[0],x[1],x[2]))
            flag = None
            count = 0
            start = end = 0
            for DNAr in DNAregion:
                if flag == None:
                    flag = DNAr[0]
                    start = DNAr[1]
                    end = DNAr[2]
                    count = 1
                elif flag != DNAr[0] or DNAr[1] > end: # diff chrom or no overlap
                    fout.write("\t".join([flag,str(start),str(end),hashgtf[gene],".",gene,str(count),str(gene_count[gene])])+"\n")
                    flag = DNAr[0]
                    start = DNAr[1]
                    end = DNAr[2]
                    count = 1
                else:
                    end = DNAr[2]
                    count += 1
            fout.write("\t".join([flag,str(start),str(end),hashgtf[gene],".",gene,str(count),str(gene_count[gene])])+"\n")

if __name__ == "__main__":
    main(sys.argv[1],sys.argv[2],sys.argv[3])
