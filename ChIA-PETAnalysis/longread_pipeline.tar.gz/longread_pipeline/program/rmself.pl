use strict;
use warnings;

my ($in1,$in2,$in3,$out1,$out2) = @ARGV; # DNARNA.rmself.bedpe , input DNA sam , input RNA sam , output DNA sam , output RNA sam

my %hash;
open IN,"<$in1";
while(<IN>)
{
	my @tmp = split /\t/,$_;
	$hash{$tmp[6]} = 1;
}
close IN;

open IN,"<$in2";
open OUT,">$out1";
while(<IN>)
{
	if(/\@/)
	{
		print OUT $_;
		next;
	}
	my $line = $_;
	my @tmp = split /\t/,$line;
	if(exists $hash{$tmp[0]})
	{
		print OUT $line;
	}
}
close IN;
close OUT;

open IN,"<$in3";
open OUT,">$out2";
while(<IN>)
{
	if(/\@/)
	{
		print OUT $_;
		next;
	}
	my $line = $_;
	my @tmp = split /\t/,$line;
	if(exists $hash{$tmp[0]})
	{
		print OUT $line;
	}
}
close IN;
close OUT;
