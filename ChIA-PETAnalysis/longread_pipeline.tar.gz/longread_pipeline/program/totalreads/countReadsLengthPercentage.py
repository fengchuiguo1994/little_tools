import sys

### Operating common files  ###
import gzip
def readFile(infile):
    """
    infile: input file
    return: file handle
    """
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    """
    outfile: output file
    return: file handle
    """
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

N = int(sys.argv[1])
for infile in sys.argv[2:]:
    fin = readFile(infile)
    total = 0
    tmpdict = {}
    mark = ""
    for line in fin:
        tmp = line.strip().split()
        total += int(tmp[1])
        tmpdict[int(tmp[0])] = int(tmp[1])
        mark = tmp[2]
    for ii in range(N+1):
        if ii in tmpdict:
            print("{0}\t{1}\t{2}\t{3}".format(ii,tmpdict[ii],mark,tmpdict[ii]/total))
        else:
            print("{0}\t{1}\t{2}\t{3}".format(ii,0,mark,0))
    fin.close()
sys.stdout.close()