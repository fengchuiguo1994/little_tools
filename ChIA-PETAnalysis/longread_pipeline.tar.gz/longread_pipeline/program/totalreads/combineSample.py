import sys

### Operating common files  ###
import gzip
def readFile(infile):
    """
    infile: input file
    return: file handle
    """
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    """
    outfile: output file
    return: file handle
    """
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

mark = None
mydict = {}
fin1 = readFile(sys.argv[1])
fin2 = readFile(sys.argv[2])

for line in fin1:
    tmp = line.strip().split()
    mark = tmp[2].split("-")[0]
    mydict[int(tmp[0])] = int(tmp[1])

for line in fin2:
    tmp = line.strip().split()
    nn = int(tmp[0])
    if nn in mydict:
        mydict[nn] += int(tmp[1])
    else:
        mydict[nn] = int(tmp[1])

for k in sorted(mydict.keys()):
    sys.stdout.write("{0}\t{1}\t{2}\n".format(k,mydict[k],mark))
sys.stdout.close()
    
fin1.close()
fin2.close()