import sys

### Operating common files  ###
import gzip
def readFile(infile):
    """
    infile: input file
    return: file handle
    """
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    """
    outfile: output file
    return: file handle
    """
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

fcomlog = readFile(sys.argv[1]) # allrich-23.combine.fq.stat.log
fonlylog = readFile(sys.argv[2]) # allrich-23.only.maybe_true.seq
findna = readFile(sys.argv[3]) # allrich-23.DNA.fastq
finrna = readFile(sys.argv[4]) # allrich-23.RNA.fastq
mark = sys.argv[5]
fdna = writeFile(sys.argv[6])
frna = writeFile(sys.argv[7])

dnadict = {}
rnadict = {}

nline = 0
for line in fcomlog:
    nline += 1
fcomlog.close()
if nline % 2 != 0:
    sys.exit("{0} file has error".format(sys.argv[1]))
for i in range(nline//2):
    if 0 not in dnadict:
        dnadict[0] = 0
    dnadict[0] += 1
    if 0 not in rnadict:
        rnadict[0] = 0
    rnadict[0] += 1

nline = 0
for line in fonlylog:
    nline += 1
fonlylog.close()
if nline % 3 != 0:
    sys.exit("{0} file has error".format(sys.argv[2]))
for i in range(nline//3):
    if 0 not in dnadict:
        dnadict[0] = 0
    dnadict[0] += 1
    if 0 not in rnadict:
        rnadict[0] = 0
    rnadict[0] += 1

nline = 0
for line in findna:
    nline += 1
    if nline % 4 == 2:
        line = line.strip()
        if line == "#":
            if 0 not in dnadict:
                dnadict[0] = 0
            dnadict[0] += 1
        else:
            nreads = len(line)
            if nreads not in dnadict:
                dnadict[nreads] = 0
            dnadict[nreads] += 1
findna.close()

nline = 0
for line in finrna:
    nline += 1
    if nline % 4 == 2:
        line = line.strip()
        if line == "#":
            if 0 not in rnadict:
                rnadict[0] = 0
            rnadict[0] += 1
        else:
            nreads = len(line)
            if nreads not in rnadict:
                rnadict[nreads] = 0
            rnadict[nreads] += 1
finrna.close()

for k in sorted(dnadict.keys()):
    fdna.write("{0}\t{1}\t{2}\n".format(k,dnadict[k],mark,))
fdna.close()
for k in sorted(rnadict.keys()):
    frna.write("{0}\t{1}\t{2}\n".format(k,rnadict[k],mark,))
frna.close()
