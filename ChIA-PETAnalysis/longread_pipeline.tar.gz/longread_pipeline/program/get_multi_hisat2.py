import pysam
import sys

'''
python get_multi_hisat2.py allrich-23.RNA.sam allrich-23.multi.bam
'''

fin = sys.argv[1]
if fin.endswith(".bam"):
    flsam = pysam.AlignmentFile(fin,'rb')
else:
    flsam = pysam.AlignmentFile(fin,'r')

fout = pysam.AlignmentFile(sys.argv[2],'wb',header=flsam.header)
for line in flsam:
    if not line.is_unmapped:
        if line.get_tag("NH") > 1:
            fout.write(line)