import sys

import gzip
def readFile(infile):
    """
    infile: input file
    return: file handle
    """
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    """
    outfile: output file
    return: file handle
    """
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

def rc(seq):
    aa = {'A':'T','T':'A','C':'G','G':'C','a':'T','t':'A','c':'G','g':'C'}
    result = ""
    le = len(seq)
    for i in range(le):
        if seq[le-1-i] in aa:
            result += aa[seq[le-1-i]]
        else:
            result += seq[le-1-i]
    return result

fcom = readFile(sys.argv[1])
fR1 = readFile(sys.argv[2])
fR2 = readFile(sys.argv[3])
fout = writeFile(sys.argv[4])

for line in fcom:
    fout.write(line)
fcom.close()

for line in fR1:
    fout.write(line)
fR1.close()

nline = 0
for line in fR2:
    nline += 1
    if nline % 4 == 1:
        line = line.strip().split()
        line[1] = line[1].replace("2","1")
        fout.write("{0}\n".format(" ".join(line[:2])))
    elif nline % 4 == 2:
        line = line.strip()
        tmpseq = rc(line)
        fout.write(tmpseq+"\n")
    elif nline % 4 == 3:
        fout.write(line)
    else:
        line = line.strip()
        line = line[::-1]
        fout.write(line+"\n")
        nline = 0

fR2.close()
fout.close()
