import pysam
import sys

uniq = 0
multi = 0
unmap = 0
with pysam.AlignmentFile(sys.argv[1],'r') as shortfl,pysam.AlignmentFile(sys.argv[2],'r') as longfl:
    header = longfl.header.to_dict()
    header['PG'].append(shortfl.header['PG'][0])
    with pysam.AlignmentFile(sys.argv[3],'wb',header=header) as outfl:
        for line in shortfl:
            if line.is_unmapped:
                unmap += 1
            else:
                if line.get_tag('XT')=="U":
                    outfl.write(line)
                    uniq += 1
                else:
                    multi += 1
        for line in longfl:
            if line.is_unmapped:
                unmap += 1
            else:
                if line.get_tag('AS') != line.get_tag('XS'):
                    outfl.write(line)
                    uniq += 1
                else:
                    multi += 1

print("unmap reads: {0}".format(unmap))
print("uniqmap reads: {0}".format(uniq))
print("multimap reads: {0}".format(multi))
