import sys
import re
import pysam

## python ~/longread_pipeline/longread_pipeline/program/logfile.py allrich-23 allrich-23 allrich-23.sh.run.out

def count_file(flin):
    count = 0
    with open(flin,'r') as fin:
        for line in fin:
            line = line.strip()
            if line != "":
                count += 1
    return count

path = sys.argv[1]
prefix = sys.argv[2]
logfile = sys.argv[3]
total = combine = only = 0
flin = logfile
with open(flin,'r') as fin:
    for line in fin:
        if re.search(r'Total pairs:\s+(\d+)',line):
            total = re.search(r'Total pairs:\s+(\d+)',line)[1]
        if re.search(r'Combined pairs:\s+(\d+)',line):
            combine = re.search(r'Combined pairs:\s+(\d+)',line)[1]
        if re.search(r'Uncombined pairs:\s+(\d+)',line):
            only = re.search(r'Uncombined pairs:\s+(\d+)',line)[1]
print("total reads:{0}\ncombine reads:{1}\nuncombine reads:{2}\n".format(total,combine,only))

comt = comb0 = comb1 = comb2 = comb3 = 0
flin = "{0}/{1}.combine.fq.stat".format(path,prefix)
with open(flin,'r') as fin:
    for line in fin:
        tmp = line.strip().split()
        if re.search(r'_',tmp[0]) or re.search(r'-',tmp[0]):
            continue
        comt += int(tmp[1])
        if tmp[0] == '0':
            comb0 += int(tmp[1])
        elif tmp[0] == '1':
            comb1 += int(tmp[1])
        elif tmp[0] == '2':
            comb2 += int(tmp[1])
        else:
            comb3 += int(tmp[1])
print("combine total reads:{0}\ncombine 0 linker reads:{1}\ncombine 1 linker reads:{2}\ncombine 2 linker reads:{3}\ncombine >2 linker reads:{4}\n".format(comt,comb0,comb1,comb2,comb3))

onlyt = only0 = only1 = only2 = only3 = 0
flin = "{0}/{1}.only.fq.stat".format(path,prefix)
with open(flin,'r') as fin:
    for line in fin:
        if re.search(r':',line):
            continue
        if re.search(r'question6',line):
            continue
        tmp = line.strip().split()
        if re.search(r'_',tmp[0]) or re.search(r'-',tmp[0]):
            continue
        onlyt += int(tmp[1])
        if tmp[0] == '0':
            only0 += int(tmp[1])
        elif tmp[0] == '1':
            only1 += int(tmp[1])
        elif tmp[0] == '2':
            only2 += int(tmp[1])
        else:
            only3 += int(tmp[1])
print("uncombine total reads:{0}\nuncombine 0 linker reads:{1}\nuncombine 1 linker reads:{2}\nuncombine 2 linker reads:{3}\nuncombine >2 linker reads:{4}\n".format(onlyt,only0,only1,only2,only3))

flin = "{0}/{1}.only.fq.stat.log".format(path,prefix)
link2 = {}
with open(flin,'r') as fin:
    for line in fin:
        line = line.strip()
        if line not in link2:
            link2[line] = 0
        link2[line] += 1
for i in sorted(link2.keys()):
    print("{0}:{1}".format(i,link2[i]))
print()

combcount = onlycount = 0
flin = "{0}/{1}.combine.RNA.fq".format(path,prefix)
combcount = count_file(flin)
combcount /= 4
combcount = int(combcount)
flin = "{0}/{1}.only.RNA.fq".format(path,prefix)
onlycount = count_file(flin)
onlycount /= 4
onlycount = int(onlycount)
totalreads = combcount + onlycount
ambiguous = comb0 + only0
print("combcount available reads:{0}\nuncombcount available reads:{1}\navailable reads:{2}\nambiguous reads:{3}\n".format(combcount,onlycount,totalreads,ambiguous))


uniqdna = uniqrna = 0
flin = "{0}/{1}.DNA.sam".format(path,prefix)
with open(flin,'r') as fin:
    for line in fin:
        if not line.startswith(r'@'):
            uniqdna += 1
# flin = "{0}/{1}.RNA.flt.bam".format(path,prefix)
flin = "{0}/{1}.RNA.bam".format(path,prefix)
samfl = pysam.AlignmentFile(flin,'rb')
for line in samfl:
    uniqrna += 1
samfl.close()
print("uniq dna reads:{0}\nuniq rna reads:{1}\n".format(uniqdna,uniqrna))

total_pet = uniq_pet = cluster = clustergt2 = clustergt3 = clustergt4 = 0
flag = {}
flin = "{0}/interaction/{1}.DNARNA.bedpe".format(path,prefix)
total_pet = count_file(flin)
flin = "{0}/interaction/{1}.DNARNA.uniq.bedpe".format(path,prefix)
with open(flin,'r') as fin:
    for line in fin:
        uniq_pet += 1
        tmp = line.strip().split("\t")
        DNA = "anchor"
        RNA = "gene"
        if tmp[12] == ".":
            DNA = "noanchor"
        if tmp[13] == "__no_feature":
            RNA = "nogene"
        tmpflag = DNA+"-"+RNA
        if tmpflag not in flag:
            flag[tmpflag] = 0
        flag[tmpflag] += 1
flin = "{0}/interaction/{1}.DNARNA.givenanchor.FDRfiltered.txt".format(path,prefix)
with open(flin,'r') as fin:
    for line in fin:
        tmp = line.strip().split("\t")
        if int(tmp[8]) > 4:
            clustergt4 += 1
        if int(tmp[8]) > 3:
            clustergt3 += 1
        if int(tmp[8]) > 2:
            clustergt2 += 1
        cluster += 1
print("total PET:{0}".format(total_pet))
print("uniq PET:{0}".format(uniq_pet))
for i in flag.keys():
    print("{0}:{1}".format(i,flag[i]))
print("cluster:{0}".format(cluster))
print("cluster > 2:{0}".format(clustergt2))
print("cluster > 3:{0}".format(clustergt3))
print("cluster > 4:{0}".format(clustergt4))

