import sys

def compare(mylist):
    out = []
    for i in mylist:
        out.append(i[10])
    print("\t".join(mylist[0][0:7])+"\t"+";".join(out))

if len(sys.argv) >= 2:
    fin = open(sys.argv[1],'r')
else:
    fin = sys.stdin

flag = None
out = []
for line in fin:
    tmp = line.strip().split("\t")
    ID = "\t".join(tmp[0:7])
    if flag != None and flag != ID:
        compare(out)
        out = []
    flag = ID
    out.append(tmp)
compare(out)
fin.close()