import sys

### Operating sam/bam files  ###
import pysam
def readSam(insamfile):
    """
    insamfile: input sam/bam file
    return: file handle
    """
    if insamfile.endswith(".bam"):
        insam = pysam.AlignmentFile(insamfile,'rb')
    elif insamfile.endswith(".sam.gz"):
        insam = pysam.AlignmentFile(insamfile,'rb')
    elif insamfile.endswith(".sam"):
        insam = pysam.AlignmentFile(insamfile,'r')
    else:
        raise ValueError("the input sam/bam file is not end with sam or bam!")
    return insam
        
def writeSam(outsamfile,header):
    """
    outsamfile: output sam/bam file
    header: the sam/bam file's header(chromosome information, created by insam.handle)
    return: file handle
    """
    if outsamfile.endswith(".bam"):
        outsam = pysam.AlignmentFile(outsamfile,'wb',header=header)
    elif outsamfile.endswith(".sam"):
        outsam = pysam.AlignmentFile(outsamfile,'w',header=header)
    else:
        raise ValueError("the output sam/bam file is not end with sam or bam!")
    return outsam

class SamRead:
    """
    get sam read
    """
    def __init__(self,infile):
        self.fin = readSam(infile)
    def __iter__(self):
        flag = None
        outlist = []
        for read in self.fin:
            if flag != None and flag != read.query_name:
                yield outlist
                outlist = []
            outlist.append(read)
            flag = read.query_name
        self.fin.close()
        yield outlist
    def header(self):
        return self.fin.header

def MAX(mylist):
    qual = mylist[0].mapping_quality
    AS = mylist[0].get_tag("AS")
    XS = mylist[0].get_tag("XS")
    out = mylist[0]
    for ii in mylist:
        if ii.get_tag("AS") - ii.get_tag("XS") > AS - XS:
            qual = ii.mapping_quality
            AS = ii.get_tag("AS")
            XS = ii.get_tag("XS")
            out = ii
        elif ii.get_tag("AS") - ii.get_tag("XS") == AS - XS and ii.mapping_quality > qual:
            qual = ii.mapping_quality
            AS = ii.get_tag("AS")
            XS = ii.get_tag("XS")
            out = ii
    return out
    
fin = SamRead(sys.argv[1])
fout = writeSam(sys.argv[2],header=fin.header())

for reads in fin:
    if len(reads) == 1:
        fout.write(reads[0])
    else:
        fout.write(MAX(reads))

fout.close()