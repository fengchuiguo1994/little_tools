import sys
import networkx as nx
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import time

mypoint = set()
mylink = []
print('begin to read input file')
be = time.time()

with open(sys.argv[1],'r') as fin:
    for line in fin:
        tmp = line.strip().split("\t")
        id1 = tmp[0]+":"+tmp[1]+"-"+tmp[2]
        id2 = tmp[3]+":"+tmp[4]+"-"+tmp[5]
        mypoint.add(id1)
        mypoint.add(id2)
        mylink.append((id1,id2))

usetime = time.time()-be
print("finish reading file,use time %f s" % (time.time()-be))

out1 = sys.argv[2]+".raw.txt"
out2 = sys.argv[2]+".anchor.txt"
out3 = sys.argv[2]+".link.txt"
out4 = sys.argv[2]+".subgraph.pdf"
fout1 = open(out1,'w')
fout2 = open(out2,'w')
fout3 = open(out3,'w')
fout4 = open(out4,'w')
pp = PdfPages(out4)


G = nx.Graph()
for node in mypoint:
    G.add_node(node)
for link in mylink:
    G.add_edge(link[0], link[1])

fout1.write("output all nodes :{}\n".format(G.nodes()))
fout1.write("output all edges :{}\n".format(G.edges()))
fout1.write("output the count of edges :{}\n".format(G.number_of_edges()))
fout2.write("\t".join(list(G.nodes()))+"\n")
tmpout = []
for i in G.edges():
    tmpout.append(",".join(i))
fout3.write("\t".join(tmpout)+"\n")
color =['r','y','g','b']

# 打印连通子图
for i,c in enumerate(nx.connected_components(G)):
    print("deal with the number %d subgraph" % (i+1))
    # 得到不连通的子集
    nodeSet = G.subgraph(c).nodes()
    # 绘制子图
    subgraph = G.subgraph(c)
    fout1.write("output all nodes :{}\n".format(subgraph.nodes()))
    fout1.write("output all edges :{}\n".format(subgraph.edges()))
    fout1.write("output the count of edges :{}\n".format(subgraph.number_of_edges()))
    fout2.write("\t".join(list(subgraph.nodes()))+"\n")
    tmpout = []
    for k in subgraph.edges():
        tmpout.append(",".join(k))
    fout3.write("\t".join(tmpout)+"\n")
    nx.draw_networkx(subgraph, with_labels=True,node_size=100,alpha=1,font_size=3,node_color=color[i%len(color)])
    plt.savefig(pp, format='pdf')
    plt.close()

fout1.close()
fout2.close()
fout3.close()
pp.close()