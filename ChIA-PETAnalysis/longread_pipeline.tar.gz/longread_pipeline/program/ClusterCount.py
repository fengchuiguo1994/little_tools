from bx.intervals.intersection import Intersecter, Interval
import sys

def main(clusterfile,bedfile,outfile):
    # load bed file
    resFrag = {}
    with open(bedfile,'r') as fin:
        for line in fin:
            tmp = line.strip().split()
            # build intervals Tree
            if tmp[0] not in resFrag:
                resFrag[tmp[0]] = Intersecter()
            resFrag[tmp[0]].add_interval(Interval(int(tmp[1]),int(tmp[2])))
    
    # load cluster file
    regioncount = {}
    with open(clusterfile,'r') as fin,open(outfile,'w') as fout:
        for line in fin:
            tmp = line.strip().split()
            if int(tmp[8]) < 2:
                continue
            flag = tmp[0]+"\t"+tmp[1]+"\t"+tmp[2]
            dna_count = 0
            if flag not in regioncount:
                if tmp[0] in resFrag:
                    dna_count = len(resFrag[tmp[0]].find(int(tmp[1]),int(tmp[2])))
                regioncount[flag] = dna_count
            else:
                dna_count = regioncount[flag]
            fout.write("\t".join(tmp[:9])+"\t"+str(dna_count)+"\t"+tmp[9]+"\n")

if __name__ == "__main__":
    # cluster file          bedpe file             out file
    main(sys.argv[1],sys.argv[2],sys.argv[3])