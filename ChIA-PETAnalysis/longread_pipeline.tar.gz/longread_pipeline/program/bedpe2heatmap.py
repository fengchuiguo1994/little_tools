import sys
from operator import itemgetter

flag = {}
with open(sys.argv[1],'r') as fin:
    for line in fin:
        tmp = line.strip().split("\t")
        dnaid = (tmp[14],int(tmp[15]),int(tmp[16]),tmp[17])
        rna = tmp[13].split(";")
        for i in rna:
            rnaid = i.split("-")[0]
            if rnaid not in flag:
                flag[rnaid] = {}
            if dnaid not in flag[rnaid]:
                flag[rnaid][dnaid] = 0
            flag[rnaid][dnaid] += 1
with open(sys.argv[2],'r') as fin:
#chr1	1785285	1891117	ENSG00000078369	22490	-	chr1	922000	82.8909
    for line in fin:
        tmp = line.strip().split("\t")
        if tmp[6] not in flag:
            continue
        dna = flag[tmp[6]].keys()
        for dna in sorted(dna,key=itemgetter(0,1,2)):
            print("{0}\t{1}\t{2}\t{3}\t{4}\t{5}".format(tmp[0],tmp[1],tmp[2],tmp[6],"\t".join(map(str,dna)),flag[tmp[6]][dna]))