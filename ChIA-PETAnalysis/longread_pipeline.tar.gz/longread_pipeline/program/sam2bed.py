import pysam
import sys
import re
import operator

def main(samfin):
    if re.match("bam",samfin):
        samfile=pysam.AlignmentFile(samfin,'rb')
    else:
        samfile=pysam.AlignmentFile(samfin)
    gene={}
    ambiguous=[]
    for line in samfile:
        if line.is_reverse:
            strand = "-"
        else:
            strand = "+"
        if line.get_tag("GE") == "__no_feature":
            gene["__no_feature"] = gene.setdefault("__no_feature",0)+1
            print("\t".join([line.reference_name,str(line.reference_start),str(line.reference_end),line.query_name,str(line.mapping_quality),strand,line.cigarstring,"__no_feature"]))
        elif not re.match("__ambiguous",line.get_tag("GE")):
            print("\t".join([line.reference_name,str(line.reference_start),str(line.reference_end),line.query_name,str(line.mapping_quality),strand,line.cigarstring,line.get_tag("GE")]))
            gene[line.get_tag("GE")] = gene.setdefault(line.get_tag("GE"),0)+1
        else:
            if not (re.match("__ambiguous",line.get_tag("XF")) or re.match("__no_feature",line.get_tag("XF"))):
                print("\t".join([line.reference_name,str(line.reference_start),str(line.reference_end),line.query_name,str(line.mapping_quality),strand,line.cigarstring,line.get_tag("XF")]))
                gene[line.get_tag("XF")] = gene.setdefault(line.get_tag("XF"),0)+1
            else:
                ambiguous.append(line)

    for line in ambiguous:
        if line.is_reverse:
            strand = "-"
        else:
            strand = "+"
        genelist = re.search("\[(.+?)\]",line.get_tag("GE"))[1].split("+")
        tmp = {}
        for i in genelist:
            tmp[i] = gene.setdefault(i,0)
        genesort = sorted(tmp.items(),key=operator.itemgetter(1))
        if (genesort[-1][1]+0.1)/(genesort[-2][1]+0.1) >=3:
            print("\t".join([line.reference_name,str(line.reference_start),str(line.reference_end),line.query_name,str(line.mapping_quality),strand,line.cigarstring,genesort[-1][0],str(genesort[-1][1]),str(genesort[-2][1])]))
            gene[genesort[-1][0]] = gene.setdefault(genesort[-1][0],0)+1
        else:
            gene["__ambiguous"] = gene.setdefault("__ambiguous",0)+1
            print("\t".join([line.reference_name,str(line.reference_start),str(line.reference_end),line.query_name,str(line.mapping_quality),strand,line.cigarstring,"__ambiguous"]))
    for i,j in sorted(gene.items(),key=operator.itemgetter(0)):
        sys.stderr.write("\t".join([i,str(j),"\n"]))

if __name__ == "__main__":
    main(sys.argv[1])
