from os import replace
import sys

### Operating common files  ###
import gzip
def readFile(infile):
    """
    infile: input file
    return: file handle
    """
    if infile.endswith((".gz","gzip")):
        fin = gzip.open(infile,'rt')
    else:
        fin = open(infile,'r')
    return fin
        
def writeFile(outfile):
    """
    outfile: output file
    return: file handle
    """
    if outfile.endswith((".gz","gzip")):
        fout = gzip.open(outfile,'wt')
    else:
        fout = open(outfile,'w')
    return fout

### Operating sam/bam files  ###
import pysam
def readSam(insamfile):
    """
    insamfile: input sam/bam file
    return: file handle
    """
    if insamfile.endswith(".bam"):
        insam = pysam.AlignmentFile(insamfile,'rb')
    elif insamfile.endswith(".sam"):
        insam = pysam.AlignmentFile(insamfile,'r')
    else:
        raise ValueError("the input sam/bam file is not end with sam or bam!")
    return insam
        
def writeSam(outsamfile,header):
    """
    outsamfile: output sam/bam file
    header: the sam/bam file's header(chromosome information, created by insam.handle)
    return: file handle
    """
    if outsamfile.endswith(".bam"):
        outsam = pysam.AlignmentFile(outsamfile,'wb',header=header)
    elif outsamfile.endswith(".sam"):
        outsam = pysam.AlignmentFile(outsamfile,'w',header=header)
    else:
        raise ValueError("the output sam/bam file is not end with sam or bam!")
    return outsam

class SamRead:
    """
    get sam read
    """
    def __init__(self,infile):
        self.fin = readSam(infile)
    def __iter__(self):
        flag = None
        outlist = []
        for read in self.fin:
            if flag != None and flag != read.query_name:
                yield outlist
                outlist = []
            outlist.append(read)
            flag = read.query_name
        self.fin.close()
        yield outlist
    def header(self):
        return self.fin.header

mydict = {}
fin = readFile(sys.argv[2])
for line in fin:
    line = line.strip()
    if line == "":
        continue
    tmp = line.split()
    mydict[tmp[0]] = tmp[1]
fin.close()

fin = SamRead(sys.argv[1])
fout = writeFile(sys.argv[3])
fbed = writeFile(sys.argv[4])
fsam = writeSam(sys.argv[5], header=fin.header())
tmpset = set()
target = set()
for readlist in fin:
    if len(readlist) == 1:
        if readlist[0].is_unmapped: # unmapped
            fout.write("@{0}\n{1}\n+\n{2}\n".format(
                readlist[0].query_name, readlist[0].get_forward_sequence(), pysam.array_to_qualitystring(readlist[0].get_forward_qualities())))
        else:
            if readlist[0].get_tag("XT") == "U": # uniq
                strand = "+"
                if readlist[0].is_reverse:
                    strand = "-"
                fbed.write("{0}\t{1}\t{2}\t{3}\t.\t{4}\tuniq\t{5}\n".format(
                    readlist[0].reference_name, readlist[0].reference_start, readlist[0].reference_end, readlist[0].query_name, strand, mydict[readlist[0].reference_name]))
            elif readlist[0].get_tag("XT") == "N": # unmapped
                fout.write("@{0}\n{1}\n+\n{2}\n".format(
                    readlist[0].query_name, readlist[0].get_forward_sequence(), pysam.array_to_qualitystring(readlist[0].get_forward_qualities())))
            elif readlist[0].get_tag("XT") == "M": # jiu
                sys.exit("single end reads align by bwa aln has no XT:A:M! \n{0}".format(readlist[0].to_string()))
            else: 
                if readlist[0].has_tag("XA"): # multi
                    tmpset = set()
                    target = set()
                    strand = "+"
                    if readlist[0].is_reverse:
                        strand = "-"
                    tmpset.add("{0}##{1}".format(readlist[0].reference_name, strand))
                    target.add("{0}##{1}".format(mydict[readlist[0].reference_name], strand))
                    for ii in readlist[0].get_tag("XA").split(";"):
                        if ii == "":
                            continue
                        chrom, pos, cigar, mis = ii.split(",")
                        strand = pos[0]
                        tmpset.add("{0}##{1}".format(chrom, strand))
                        target.add("{0}##{1}".format(mydict[chrom], strand))
                    if len(tmpset) == 1:
                        ch,st = list(tmpset)[0].split("##")
                        fbed.write("-\t-\t-\t{0}\t.\t{1}\tmulti\t{2}\n".format(
                            readlist[0].query_name,st,mydict[ch]))
                    elif len(target) == 1:
                        ch,st = list(target)[0].split("##")
                        fbed.write("-\t-\t-\t{0}\t.\t{1}\tmulti\t{2}\n".format(
                            readlist[0].query_name,st,ch))
                    elif len(target) == 2:
                        if "Alu##+" in target and "7SL##+" in target:
                            fbed.write("-\t-\t-\t{0}\t.\t+\tmulti\t7SL\n".format(
                            readlist[0].query_name))
                        else:
                            for iii in readlist:
                                fsam.write(iii)
                    else:
                        for iii in readlist:
                            fsam.write(iii)
                else: # unknow multi
                    fsam.write(readlist[0])
    else: # multi
        sys.exit("bwa aln result no multi reads ID! \n{0}".format(readlist[0].to_string()))
fout.close()
fbed.close()
fsam.close()