import sys
"""
calculator the reads length
python static_reads_length.py path prefix output flag
python static_reads_length.py allrich-06 allrich-06 allrich-06.length.txt allrich-06
"""
fdna = "{0}/{1}.DNA.fastq".format(sys.argv[1],sys.argv[2])
frna = "{0}/{1}.RNA.fastq".format(sys.argv[1],sys.argv[2])
flag = sys.argv[4]
with open(fdna,'r') as dna,open(frna,'r') as rna,open(sys.argv[3],'w') as fout:
    fout.write("length\tsample\ttype\n")
    for n,line in enumerate(dna):
        line = line.strip()
        if (n+1)%4 == 2:
            fout.write("{0}\t{1}\tDNA\n".format(len(line),flag))
    for n,line in enumerate(rna):
        line = line.strip()
        if (n+1)%4 == 2:
            fout.write("{0}\t{1}\tRNA\n".format(len(line),flag))