use strict;
use warnings;

my ($cluster,$dna_anchor,$rna_anchor,$out) = @ARGV; #pre_cluster.txt dna_anchor_file(peak file) rna_anchor_file(gene bed file) output_file
open IN,"<$dna_anchor";
my (%dna,%rna);
while(<IN>)
{
	chomp;
	my @tmp = split/\s+/,$_;
	push@{$dna{$tmp[0]}},[@tmp[1,2]];
}
close IN;

open IN,"<$rna_anchor";
while(<IN>)
{
	chomp;
	my @tmp = split/\s+/,$_;
	push@{$rna{$tmp[0]}},[@tmp[1,2]];
}
close IN;

open IN,"<$cluster";
my %hash;
while(<IN>)
{
	chomp;
	my @tmp = split/\s+/,$_;
	my (@dna_out,@rna_out);
	foreach(@{$dna{$tmp[0]}})
	{
		my @dna_tmp = @{$_};
		if($dna_tmp[1] < $tmp[1])#zhongdian xiaoyu qidian
		{
			next;
		}
		elsif($dna_tmp[0] > $tmp[2])#qidian dayu zhongdian
		{
			last;
		}
		elsif(($dna_tmp[1]-$tmp[1])*($dna_tmp[0]-$tmp[2]) <= 0)#overlap
		{
			push@dna_out,"$tmp[0]\t$dna_tmp[0]\t$dna_tmp[1]";
		}
		else
		{
			die "it have some error\n";
		}
	}
	
	foreach(@{$rna{$tmp[4]}})
	{
		my @rna_tmp = @{$_};
		if($rna_tmp[1] < $tmp[5])
		{
			next;
		}
		elsif($rna_tmp[0] > $tmp[6])
		{
			last;
		}
		elsif(($rna_tmp[1]-$tmp[5])*($rna_tmp[0]-$tmp[6]) <= 0)#overlap
		{
			push@rna_out,"$tmp[4]\t$rna_tmp[0]\t$rna_tmp[1]";
		}
		else
		{
			die "it have some error\n";
		}
	}
	if(scalar(@dna_out)>0 && scalar(@rna_out)>0)
	{
		foreach my $i (@dna_out)
		{
			foreach my $j (@rna_out)
			{
				$hash{"$i\t$j"} += 1;
			}
		}
	}
}

open OUT,">$out";
#chr1	804147	804647	0	0	0	chr1	211947845	211948345	0     211143698	0.0	---
foreach my $i (keys %hash)
{
	my @key = split/\t/,$i;
	my $count = $hash{$i};
	my $flag = 1;#1 intra			0 inter
	my $distance = abs(int(($key[4]+$key[5]-$key[1]-$key[2])/2));
	if($key[0] ne $key[3])
	{
		$flag = 0;
		$distance = 2147483647;
	}
	print OUT "$key[0]\t$key[1]\t$key[2]\t0\t0\t0\t$key[3]\t$key[4]\t$key[5]\t0\t0\t0\t$count\t$flag\t$distance\t0.0\t---\n";
}
close IN;
close OUT;
