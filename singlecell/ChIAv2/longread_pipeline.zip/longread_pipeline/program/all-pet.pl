use strict;
use warnings;

open IN1,"<$ARGV[0]"; #DNA bed file
open IN2,"<$ARGV[1]"; #RNA bed file
open OUT,">$ARGV[2]"; #out bed file
my $cutoff = $ARGV[3] || 20;

my %dna;
while(<IN1>){
	chomp;
	my @tmp = split /\t/,$_;
	next if($tmp[4] < $cutoff);
	$dna{$tmp[3]} = [@tmp];
}
close IN1;

while(<IN2>){
	chomp;
	my @tmp = split /\t/,$_;
	next if($tmp[4] < $cutoff);
	if(exists $dna{$tmp[3]}){
		my ($begin,$end) = &sharp(@tmp);
		print OUT "${$dna{$tmp[3]}}[0]\t${$dna{$tmp[3]}}[1]\t${$dna{$tmp[3]}}[2]\t$tmp[0]\t$begin\t$end\t$tmp[3]\t$cutoff\t${$dna{$tmp[3]}}[5]\t$tmp[5]\n";
	}
}

sub sharp{
	my @tmp = @_;
	my $begin = $tmp[1];
	my @aaa = $tmp[6] =~ /(\d+[A-Z])/g;
=pod
Op		BAM	Description												Consumes query	Consumes reference
M		0	alignment match (can be a sequence match or mismatch)	yes				yes
I		1	insertion to the reference								yes				no
D		2	deletion from the reference								no				yes
N		3	skipped region from the reference						no				yes
S		4	soft clipping (clipped sequences present in SEQ)		yes				no
H		5	hard clipping (clipped sequences NOT present in SEQ)	no				no
P		6	padding (silent deletion from padded reference)			no				no
=		7	sequence match											yes				yes
X		8	sequence mismatch										yes				yes
=cut
#debug from 44 to 63. add D and remove ISH influences
	my @bbb = grep{/[MDN]/}@aaa;
	my $i = 1;
	my $out = 0;
	undef @aaa;
	foreach(@bbb)
	{
		my ($len,$flag) = ($1,$2) if($_ =~ /(\d+)([A-Z])/);
		if($flag ne 'N')
		{
			$out += $len;
		}
		else
		{
			push @aaa,"${out}M";
			push @aaa,"$len$flag";
			$out = 0;
		}
	}
	push @aaa,"${out}M" if($out > 0);
	my $qian = 0;
	my $max = 0;
	my $index = -1;
	my @max;
	foreach(@aaa){
		my ($len,$flag) = ($1,$2) if($_ =~ /(\d+)([A-Z])/);
		if($flag ne 'M'){
			$qian += $len;
		}
		else{
			if($max > $len){
				$qian += $len;
			}
			else{
				push @max,$qian;
				$max = $len;
				$qian += $len;
				$index ++;
			}
		}
	}
	$begin += $max[$index];
	my $end = $begin+$max;
	return($begin,$end);
}
