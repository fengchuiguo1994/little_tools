use strict;
use warnings;

my ($aln,$anchor,$out,$extension,$mode) = @ARGV;
#mode:1:from 5' to 3'
#mode:2:form 3' to 5'
#mode:0:both

#load aln file
my (%hash,%anchor);#Global
my (@tmp,$start,$end,$tmp);#Local
open IN,"<$aln";
while(<IN>)
{
	chomp;
	@tmp = split /\t/,$_;
	if($tmp[2] eq '-')
	{
		if($mode == 0)
		{
			$start = $tmp[1]-$extension;
			$end = $tmp[1]+$extension;
		}
		elsif($mode == 1)
		{
			$start = $tmp[1]-$extension;
			$end = $tmp[1];
		}
		else
		{
			$start = $tmp[1];
			$end = $tmp[1]+$extension;
		}
	}
	else
	{
		if($mode == 0)
		{
			$start = $tmp[1]-$extension;
			$end = $tmp[1]+$extension;
		}
		elsif($mode == 1)
		{
			$start = $tmp[1];
			$end = $tmp[1]+$extension;
		}
		else
		{
			$start = $tmp[1]-$extension;
			$end = $tmp[1];
		}
	}
	push @{$hash{$tmp[0]}},[$start,$end];
}
close IN;

#sort aln file
foreach(keys %hash)
{
	@tmp = @{$hash{$_}};
	$hash{$_} = [sort{$a->[0] <=> $b->[0] || $a->[1] <=> $b->[1]}@tmp];
}
undef @tmp;

#load anchor file

open IN,"<$anchor";
open OUT,">$out";
while(<IN>)
{
	chomp;
	@tmp = split /\t/,$_;
	$tmp = join("\t",@tmp[0..2]);
	if(!exists $anchor{$tmp})
	{
		my $num = 0;
		foreach (@{$hash{$tmp[0]}})
		{
			my @arr = @{$_};
			if($tmp[1] >= $arr[1])#target(begin) > set(end)
			{
				next;
			}
			elsif($tmp[2] <= $arr[0])#target(end) < set(begin)
			{
				last;
			}
			else
			{
				$num += 1;
			}
		}
		$anchor{$tmp} = $num;
	}
	print OUT join("\t",@tmp)."\t$anchor{$tmp}\n";
}
close IN;
close OUT;
