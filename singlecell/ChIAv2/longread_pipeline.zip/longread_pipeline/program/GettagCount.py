import sys

def main(cluster,dna,rna):
    hashd = {}
    hashr = {}
    with open(cluster) as clt,open(dna) as dnafl,open(rna) as rnafl:
        for line in dnafl:
            tmp = line.strip().split()
            did = "\t".join(tmp[0:3])
            hashd[did] = tmp[3]
        for line in rnafl:
            tmp = line.strip().split()
            hashr[tmp[0]] = tmp[1]
        for line in clt:
            tmp = line.strip().split()
            did = "\t".join(tmp[0:3])
            print("\t".join([line.strip(),hashd[did],hashr[tmp[7]]]))

if __name__ == "__main__":
    main(sys.argv[1],sys.argv[2],sys.argv[3])