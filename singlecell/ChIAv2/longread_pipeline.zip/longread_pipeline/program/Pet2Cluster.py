import sys

def main(filein,filegtf):
    hashgtf = {}
    chrom = start = end = gene = None
    count = 0
    with open(filein) as fin,open(filegtf) as gtf:
        for line in gtf:
            tmp = line.strip().split()
            hashgtf[tmp[6]] = "\t".join([tmp[0],tmp[1],tmp[2],tmp[5]])

        for line in fin:
            tmp = line.strip().split()
            if chrom == None:
                chrom = tmp[0]
                start = int(tmp[1])
                end = int(tmp[2])
                gene = tmp[12]
                count = 1
            elif tmp[12] != gene or chrom != tmp[0] or int(tmp[1]) > end: # diff gene | diff chrom | no overlap flush
                print("\t".join([chrom,str(start),str(end),hashgtf[gene],gene,str(count)]))
                chrom = tmp[0]
                start = int(tmp[1])
                end = int(tmp[2])
                gene = tmp[12]
                count = 1
            else:
                if int(tmp[2]) > end:
                    end = int(tmp[2])
                count += 1
        print("\t".join([chrom,str(start),str(end),hashgtf[gene],gene,str(count)]))

if __name__ == "__main__":
    main(sys.argv[1],sys.argv[2])