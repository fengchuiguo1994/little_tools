import sys
import re
from operator import itemgetter

numdat = []
chardat = []
with open(sys.argv[1],'r') as fin:
    for line in fin:
        tmp = line.strip().split("\t")
        tmp[0] = re.sub("^chr","",tmp[0])
        tmp[1] = int(tmp[1])
        tmp[2] = int(tmp[2])
        if re.match("[0-9]+",tmp[0]):
            tmp[0] = int(tmp[0])
            numdat.append(tmp)
        else:
            chardat.append(tmp)
for i in sorted(numdat,key=itemgetter(0,1,2)):
    i = list(map(str,i))
    i[0] = "chr"+i[0]
    print("\t".join(i))
for i in sorted(chardat,key=itemgetter(0,1,2)):
    i = list(map(str,i))
    i[0] = "chr"+i[0]
    print("\t".join(i))