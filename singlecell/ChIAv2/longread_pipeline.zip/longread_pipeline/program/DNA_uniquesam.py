import pysam
import sys

def compare_out(mylist,outfl):
    if len(mylist) == 1:
        outfl.write(mylist[0][0])
    else:
        for line in mylist:
            line.append(line[0].get_tag("AS") - line[0].get_tag("XS"))
            line.append(line[0].mapping_quality)
            line.append(line[0].query_alignment_length)
            line.append(line[0].flag)
        outfl.write(sorted(mylist,key=lambda x:(x[1],x[2],x[3],0-x[4]),reverse=True)[0][0])
        
if sys.argv[1].endswith(".bam"):
    samfl = pysam.AlignmentFile(sys.argv[1],'rb')
else:
    samfl = pysam.AlignmentFile(sys.argv[1],'r')
if sys.argv[2].endswith(".bam"):
    outfl = pysam.AlignmentFile(sys.argv[2],'wb',header=samfl.header)
else:
    outfl = pysam.AlignmentFile(sys.argv[2],'w',header=samfl.header)

flag = None
out = []
for reads in samfl:
    if flag != None and flag != reads.qname:
        compare_out(out,outfl)
        out = []
    flag = reads.qname
    out.append([reads])
compare_out(out,outfl)

samfl.close()
outfl.close()