use strict;
use warnings;

my ($in,$out,$extend,$geneinfo) = @ARGV;#*DNARNA.select.merge.pet.bedpe *.pre_cluster.txt 500 /public/home/xyhuang/Allpet/genome/hg19/hg19.size
my %hash;
open IN,"<$geneinfo";
while(<IN>)
{
	chomp;
	my @tmp = split/\s+/,$_;
	$hash{$tmp[0]} = $tmp[1];
}
close IN;

open IN,"<$in";
open OUT,">$out";
while(<IN>)
{
	chomp;
	my $id = "SRR$.";
	my @tmp = split/\s+/,$_;
	my @output;
	if($tmp[2] eq '-')
	{
		if($tmp[1]+500 <= $hash{$tmp[0]})
		{
			push @output,($tmp[0],$tmp[1],$tmp[1]+500,$tmp[2]);
		}
		else
		{
			push @output,($tmp[0],$tmp[1],$hash{$tmp[0]},$tmp[2]);
		}
	}
	else
	{
		if($tmp[1]-500 >= 0)
                {
                        push @output,($tmp[0],$tmp[1]-500,$tmp[1],$tmp[2]);
                }
                else
                {
                        push @output,($tmp[0],0,$tmp[1],$tmp[2]);
                }
	}
	if($tmp[5] eq '-')
        {
                if($tmp[4]+500 <= $hash{$tmp[3]})
                {
                        push @output,($tmp[3],$tmp[4],$tmp[4]+500,$tmp[5]);
                }
                else
                {
                        push @output,($tmp[3],$tmp[4],$hash{$tmp[3]},$tmp[5]);
                }
        }
        else
        {
                if($tmp[4]-500 >= 0)
                {
                        push @output,($tmp[3],$tmp[4]-500,$tmp[4],$tmp[5]);
                }
                else
                {
                        push @output,($tmp[3],0,$tmp[4],$tmp[5]);
                }
        }
	push @output,($id,'1.0','---');
	print OUT join("\t",@output)."\n";
}
close IN;
close OUT;
