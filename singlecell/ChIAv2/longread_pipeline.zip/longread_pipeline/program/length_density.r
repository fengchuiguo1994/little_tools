library(ggplot2)
args=commandArgs(T)
mydat=read.table(args[1],header=T)
pdf(args[2])
ggplot(mydat, aes(x = length, fill = type , colour = type)) +
  # 密度曲线函数：alpha设置填充色透明度
  geom_density(alpha = 0,size=.8) + 
  scale_color_manual( values = c("#da1c6f","#00a0e9")) + 
  scale_x_continuous(expand = c(0,0)) + 
  scale_y_continuous(expand = c(0,0)) +
  labs(title=args[1]) + 
  theme_bw() + 
  theme(panel.grid=element_blank(),axis.line=element_line(size=1,colour="black"))
dev.off()
