PROGRAM_DIRECTORY='/home/xyhuang/Tools/longread_pipeline/longread_pipeline/program'
OUTPUT_DIRECTORY='/home/xyhuang/rich-pet/20170728/raw_data/allrich-06_result'
OUTPUT_PREFIX='allrich-06'
CHROM_SIZE_INFO='/home/xyhuang/rich-pet/genome/hg19/hg19.size'
GENOME_LENGTH='3E9'  ### human
GENOME_COVERAGE_RATIO='0.8' ### the proportion of the genome covered by the reads
BWA_GENOME_INDEX='/home/xyhuang/rich-pet/genome/hg19/hg19.fa'
HISAT_GENOME_INDEX='/home/xyhuang/rich-pet/genome/hg19/hg19'
Linker_file='/home/xyhuang/Tools/longread_pipeline/longread_pipeline/adapter.fa'
IN1='/home/xyhuang/rich-pet/20170728/raw_data/allrich-06/allrich-06_R1.fq.gz'
IN2='/home/xyhuang/rich-pet/20170728/raw_data/allrich-06/allrich-06_R2.fq.gz'

FLASH='flash'
BWA='bwa'
NTHREADS='12' ### number of threads used in mapping reads to a reference genome
SAMTOOLS='samtools'
BAM2BEDPE='bamToBed -bedpe'
MAPPING_CUTOFF='20' ### cutoff of mapping quality score for filtering out low-quality or multiply-mapped reads

MERGE_DISTANCE='2'
SELF_LIGATION_CUFOFF='8000'
EXTENSION_LENGTH='500'
PVALUE_CUTOFF_PEAK='0.00001'
PVALUE_CUTOFF_INTERACTION='0.05'

MIN_DISTANCE_BETWEEN_PEAK='500' ### minimum distance between two different peaks
MIN_COVERAGE_FOR_PEAK='5' ### minimum coverage for peaks by extended reads

###### split data to combine or independent,and find linker
time=`date '+%s'` 
#out $OUTPUT_PREFIX.flash.extendedFrags.fastq      The merged reads.
#    $OUTPUT_PREFIX.flash.notCombined_1.fastq      Read 1 of mate pairs that were not merged.
#    $OUTPUT_PREFIX.flash.notCombined_2.fastq      Read 2 of mate pairs that were not merged.
#    $OUTPUT_PREFIX.flash.hist                     Numeric histogram of merged read lengths.
#    $OUTPUT_PREFIX.flash.histogram
#flash -M 135 --output-prefix $OUTPUT_PREFIX.flash --output-directory $OUTPUT_DIRECTORY $IN1 $IN2
#$cutadapt -b file:$Linker_file -n 14 --no-indels -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.noLinker --info-file $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.Linker_info --discard -O 18 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.flash.extendedFrags.fastq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.stat
#cutadapt -b file:$Linker_file -n 8 --no-indels -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.noLinker --info-file $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.Linker_info --discard -O 18 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.flash.notCombined_1.fastq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.stat
#cutadapt -b file:$Linker_file -n 8 --no-indels -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.noLinker --info-file $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.Linker_info --discard -O 18 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.flash.notCombined_2.fastq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.stat
#perl $PROGRAM_DIRECTORY/ts_cutadapt2oneline.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.Linker_info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.cut.info
#perl $PROGRAM_DIRECTORY/ts_cutadapt2oneline.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.Linker_info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.cut.info
#perl $PROGRAM_DIRECTORY/ts_cutadapt2oneline.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.Linker_info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.cut.info

###### according linker,split RNA and DNA
#out $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.RNA.fq
#    $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.DNA.fq
#    $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only.DNA.fq
#    $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only.RNA.fq
#perl $PROGRAM_DIRECTORY/split.combine.pl  $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.cut.info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.stat
#perl $PROGRAM_DIRECTORY/split.only.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.1.cut.info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.notCombined.2.cut.info $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only.stat
#cat $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.RNA.fq $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only.RNA.fq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.fastq
#cat $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.combine.DNA.fq $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.only.DNA.fq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.fastq

####### mapping reads to a reference genome,and make multi-align to only match,sam2bam
#perl $PROGRAM_DIRECTORY/split.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.fastq $OUTPUT_DIRECTORY/$OUTPUT_PREFIX 70

#bwa aln -t $NTHREADS -f $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.sai $BWA_GENOME_INDEX $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.fastq
#bwa samse -f $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.sam $BWA_GENOME_INDEX $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.sai $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.fastq
#bwa mem -t $NTHREADS $BWA_GENOME_INDEX $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.fastq > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.sam
#hisat2 -p $NTHREADS -x $HISAT_GENOME_INDEX --rna-strandness F -U $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.fastq -S $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.sam

#java -cp $PROGRAM_DIRECTORY/LGL.jar LGL.util.UniqueSam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.sam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.rmdup.sam
#java -cp $PROGRAM_DIRECTORY/LGL.jar LGL.util.UniqueSam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.sam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.rmdup.sam
#awk '{if($2 < 256 ||/\@/){print $0;}}' $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.sam > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.rmdup.sam

#samtools view -Su $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.rmdup.sam | samtools sort -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.bam -
samtools view -Su $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.rmdup.sam | samtools sort -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.rmdup.bam -
samtools view -Su $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.rmdup.sam | samtools sort -o $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.rmdup.bam -
samtools merge -f $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.bam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.short.rmdup.bam $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.long.rmdup.bam
samtools index $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.bam
samtools index $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.bam

####### combine RNA and DNA align file to a merged bedpe file,and remove duplication reads
#out bedpe file 
#DNA(1-3) RNA(4-6) ID 20 DNAstrand RNAstrand
bamToBed -cigar -i $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.bam > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.bed
bamToBed -cigar -i $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.bam > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.bed
perl $PROGRAM_DIRECTORY/all-pet.pl $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.bed $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.bed $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.bedpe 20

sort -k1,1 -k4,4 -k2n,2 -k5n,5 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.bedpe > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.sorted.bedpe
awk -v mapping_cutoff=20 '{if(($1!=".") && ($4!=".")){print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6"\t.\t"mapping_cutoff"\t"$9"\t"$10}}' $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.sorted.bedpe > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.bedpe
uniq < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.bedpe > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.unique.bedpe

####### merge similar pet
awk '{if($9=="+"){printf $1"\t"$3"\t"$9"\t"}else{printf $1"\t"$2"\t"$9"\t"}; if($10=="+"){print $4"\t"$6"\t"$10}else{print $4"\t"$5"\t"$10}}' < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.unique.bedpe | LANG=C sort -k1,1 -k4,4 -k3,3 -k6,6 > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.pet.bedpe
java -cp $PROGRAM_DIRECTORY/LGL.jar LGL.chiapet.MergeSimilarPETs2 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.pet.bedpe $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.merge.pet.bedpe 2

####### interaction calling
java -cp $PROGRAM_DIRECTORY/LGL.jar LGL.file.Pet2Cluster1 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.merge.pet.bedpe $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pre_cluster.txt $EXTENSION_LENGTH $CHROM_SIZE_INFO 0
LANG=C sort -k1,1 -k4,4 < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pre_cluster.txt >  $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pre_cluster.sorted
java -cp $PROGRAM_DIRECTORY/LGL.jar LGL.chiapet.PetCluster2 $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pre_cluster.sorted $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster 0
awk '{if($13>=2)print}' <$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered
cut -f1-3,7-9,13-15 < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.txt

###### calculation of p-values
cut -f1-3 < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.merge.pet.bedpe > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.aln
cut -f4-6 < $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNARNA.select.merge.pet.bedpe > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.aln

cut -f1-3,13 <$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered >$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.DNA.anchor
cut -f7-9,13 <$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered >$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.RNA.anchor
for y in DNA RNA
do
    java -Xmx10G -cp $PROGRAM_DIRECTORY/LGL.jar LGL.shortReads.TagCountInGivenRegions $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.$y.aln $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.$y.anchor $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.$y.tagCount.txt 1 2
done

wc -l $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.aln | sed 's/ /\t/g' |  cut -f1 >$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.nTags.txt
wc -l $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.aln | sed 's/ /\t/g' |  cut -f1 >$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.nTags.txt
cat $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.DNA.aln $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.RNA.aln | wc -l | sed 's/ /\t/g' |  cut -f1 > nTags.txt

paste $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.DNA.tagCount.txt  $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered.RNA.tagCount.txt |  cut -f4,5,10  >$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.petCount.tagCount.txt
cp $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.petCount.tagCount.txt data.txt
R --vanilla < ${PROGRAM_DIRECTORY}/hypergeometric.r
mv -f result.txt $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pvalue.hypergeo.txt
paste $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.filtered $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.petCount.tagCount.txt $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.pvalue.hypergeo.txt | cut -f1-3,7-9,13-15,19-24 > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.withpvalue.txt
awk -v pvalue_cutoff=${PVALUE_CUTOFF_INTERACTION} '{if($13<pvalue_cutoff+0.0)print}' <$OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.withpvalue.txt > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.FDRfiltered.txt
awk '{print $7"\t"$8}' $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.FDRfiltered.txt |LANG=C sort |uniq -c | awk '{if($2>=10){a+=$1;b+=$1*$3;f+=$1;g+=$1*$3}else{c[$2]+=$1;d[$2]+=$1*$3;f+=$1;g+=$1*$3}}END{for(i in c){print c[i]"\t"i"\t"d[i]};print a"\t10\t"b;print f"\t11\t"g}' |LANG=C sort -k2,2n | awk 'BEGIN{print "PET counts\tNo. of clusters\tNo.intra-chrom clusters\tNo.inter-chrom clusters\tPercent of intra-chrom clusters"}{if($2==10){print ">="$2"\t"$1"\t"$3"\t"$1-$3"\t"$3/$1}else if($2==11){print "Total\t"$1"\t"$3"\t"$1-$3"\t"$3/$1}else{print $2"\t"$1"\t"$3"\t"$1-$3"\t"$3/$1}}'> $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.PET_count_distribution.txt

###### generate  curve
cat $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.FDRfiltered.txt |awk '{if($1==$4 && $7>3) print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6"\t"$7"\t"$12"\t"$13}' > $OUTPUT_DIRECTORY/$OUTPUT_PREFIX.cluster.intra.curve
